class Analyst(User):
    def analyze_risk(self):
        pass