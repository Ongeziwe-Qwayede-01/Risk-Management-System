class Admin(User):
    def approve_plan(self):
        pass